package dao;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.imageio.ImageIO;

import com.itextpdf.text.DocumentException;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;
import jxl.read.biff.BiffException;
import vo.Logistics;

public class creatJPG {
	int width=700;//ͼƬ����
	int height=300;//ͼƬ�߶�

    // ����jpg�ļ���ָ��·����
    public void createJpg(String path,BufferedImage image) {
        try{
            FileOutputStream fos = new FileOutputStream(path);
            BufferedOutputStream bos = new BufferedOutputStream(fos);
            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(bos);
            encoder.encode(image);
            bos.close();
            fos.close();

        }catch(FileNotFoundException fnfe){
            System.out.println(fnfe);
        }catch(IOException ioe){
            System.out.println(ioe);
        }
    }
    
    public void graphicsGeneration(Logistics log) throws FileNotFoundException, IOException
    {
    	BufferedImage image1 = ImageIO.read(new FileInputStream("./������.png"));
    	int imageWidth = 1000;// ͼƬ�Ŀ���  
        int imageHeight = 1000;// ͼƬ�ĸ߶�  
        BufferedImage image = new BufferedImage(imageWidth, imageHeight,  BufferedImage.TYPE_INT_RGB); 
        Graphics g = image.getGraphics();  
        g.setColor(Color.white);  
        g.fillRect(0, 0, imageWidth, imageHeight); //��䱳����ɫ 
        g.setColor(Color.black);
        //������Ϊ800����Ϊ400�ľ��ο�
        g.drawRect(100,100,800,400); 
        g.drawLine(100,200,900,200);
        g.drawLine(100,300,900,300);
        g.drawLine(100,400,900,400);
        g.drawLine(500,300,500,400);
        g.drawString(log.getTaskNO(), 580, 95);
        g.drawString("�ļ��ˣ�", 120, 130);
        g.drawString(log.getSender(), 220, 130);
        g.drawString("�绰/�ֻ���", 380, 130);
        g.drawString(log.getSenPhone(), 520, 130);
        g.drawString("��ַ��", 120, 160);
        g.drawString(log.getSenAdd(), 180, 160);
        g.drawString("�ʱࣺ", 120, 190);
        g.drawString(log.getSenPost(), 200, 190);
        g.drawString("�ռ��ˣ�", 120, 230);
        g.drawString(log.getRecipent(),220, 230);
        g.drawString("�绰/�ֻ���", 380, 230);
        g.drawString(log.getRecPhone(),520, 230);
        g.drawString("��ַ��", 120, 260);
        g.drawString(log.getRecipent(),220, 230);
        g.drawString("ǩ��ʱ�䣺        ��   ��   ��", 520, 380);
        g.drawString("������", 120, 330);
        g.drawString(log.getRemarks(), 220, 330);
        g.drawString("��������", 120, 380);
        g.drawString(log.getTaskNO(), 450, 488);
        g.drawImage(image1, 410, 420, 250,50, null);
        createJpg(".//�����浥.jpg", image);


    }
	public static void main(String[] args) throws BiffException, IOException, DocumentException {
		// TODO Auto-generated method stub
		String imgPath = "./������.png";     
		String imagePath = "./�����浥��Ϣ.jpg";			
		Logistics logistics=new excel().readFromExcel(file);           
        new creatcode().encode(imgPath);
		new creatJPG().graphicsGeneration(logistics);
		new creatJPG().jpgToPdf(imagePath, pdfPath);
	}

}
